# -*- coding: utf-8 -*-
"""从一段测试输出里解析 passed / failed / skipped 三项计数。"""
from __future__ import annotations

import re

# 「数字 + 指标名」，例：`10 passed` / `30 failed`
_词形 = re.compile(r"(?<!\w=)(\d+)\s+(passed|failed|skipped)")

# 「指标名 + 数字」，例：`passed=10` / `failed: 3`
_键形 = [
    ("passed", re.compile(r"passed\s*=\s*(\d+)")),
    ("failed", re.compile(r"failed\s*=\s*(\d+)")),
    ("skipped", re.compile(r"skipped\s*=\s*(\d+)")),
]


def 计数(文: str) -> dict:
    """返回 {'passed': int, 'failed': int, 'skipped': int}；没出现的项记 0。"""
    出 = {"passed": 0, "failed": 0, "skipped": 0}
    已由键形 = set()

    # key-前缀形式优先：先抓 passed=10 / failed: 3 这类明确的键值。
    for 键, 模式 in _键形:
        m = 模式.search(文 or "")
        if m:
            出[键] = int(m.group(1))
            已由键形.add(键)

    # 词形只补充 key-前缀没覆盖的项，避免 `passed=10 failed=3` 里
    # `10 failed` 把 passed 的数字误记到 failed 上。
    for 数, 键 in _词形.findall(文 or ""):
        if 键 not in 已由键形:
            出[键] = int(数)
    return 出
